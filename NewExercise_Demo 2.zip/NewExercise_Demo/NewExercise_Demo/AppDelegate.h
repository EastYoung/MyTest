//
//  AppDelegate.h
//  NewExercise_Demo
//
//  Created by 智颜科技 on 2017/11/14.
//  Copyright © 2017年 zy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

