//
//  NewExerciseViewController.m
//  NewExercise_Demo
//
//  Created by 智颜科技 on 2017/11/14.
//  Copyright © 2017年 zy. All rights reserved.
//

#import "NewExerciseViewController.h"
#import "LDCalendarView.h"
#import "NSDate+extend.h"

#define DEVICE_WIDTH [UIScreen mainScreen].bounds.size.width
#define DEVICE_HEIGHT [UIScreen mainScreen].bounds.size.height

@interface NewExerciseViewController ()
//日历控件
@property (nonatomic, strong)LDCalendarView *calendarView;
//选择的日期
@property (nonatomic, strong)NSMutableArray *seletedDays;
//显示内容
@property (nonatomic, copy)NSString *showStr;
//数据源
@property (nonatomic, strong) NSMutableArray *dataArray;


@end

@implementation NewExerciseViewController

#pragma mark - 懒加载
- (LDCalendarView *)calendarView {
    if (!_calendarView) {
        _calendarView = [[LDCalendarView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH,SCREEN_HEIGHT)];
        [self.view addSubview:_calendarView];
        
    }
    return _calendarView;
}

- (NSString *)showStr {
    NSMutableString *str = [NSMutableString string];
    
    //[str appendString:@"已选择日期:"];
    NSLog(@"arr:%@",self.seletedDays);
    //从小到大排序
    [self.seletedDays sortUsingComparator:^NSComparisonResult(NSNumber *obj1, NSNumber *obj2) {
        return [obj1 compare:obj2];
    }];
    for (NSNumber *interval in self.seletedDays) {
        NSString *partStr = [NSDate stringWithTimestamp:interval.doubleValue format:@"MM.dd"];
        [str appendFormat:@"%@ ",partStr];
    }
    
    return str.copy;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self initVariables];
    
    
    [self initViews];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - initVariables
-(void)initVariables{
    
    self.dataArray=[NSMutableArray arrayWithCapacity:0];
    
    
}

#pragma mark - initViews
-(void)initViews{
    
     //创建按钮
    for (int i = 0; i < 4; i++) {
        
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        
        btn.backgroundColor = [UIColor groupTableViewBackgroundColor];
        [btn setTitle:[NSString stringWithFormat:@"%d",i] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        btn.tag = i + 100;
        [btn addTarget:self action:@selector(clickedBtnWith:) forControlEvents:UIControlEventTouchUpInside];
        btn.frame = CGRectMake(DEVICE_WIDTH/2-300/2, 100+i*50, 300, 30);
        [self.view addSubview:btn];
    
    }
    
    
    
    
}

- (void)clickedBtnWith:(UIButton *)btn{
    
    /*
    //多选
    if (!btn.selected) {
        [btn setBackgroundColor:[UIColor brownColor]];
        [self.dataArray addObject:[NSNumber numberWithInteger:btn.tag - 100]];
    }else{
        [btn setBackgroundColor:[UIColor groupTableViewBackgroundColor]];
        if ([self.dataArray containsObject:[NSNumber numberWithInteger:btn.tag - 100]]) {
            [self.dataArray removeObject:[NSNumber numberWithInteger:btn.tag - 100]];
        }
    }
    btn.selected = !btn.selected;
    NSLog(@"%@", self.dataArray.description);
    */
    
    
      //弹出日历
      self.calendarView.defaultDays = _seletedDays;
      [self.calendarView show];
    
        __weak typeof(self) weakSelf = self;
        self.calendarView.complete = ^(NSArray *result) {
            if (result) {
                weakSelf.seletedDays = result.mutableCopy;
                [btn setTitle:weakSelf.showStr forState:UIControlStateNormal];

            }
        };
    
       btn.selected=!btn.selected;
        //单选
        if(!btn.selected==YES) {
            //将上次点击过的按钮设为黑色
            [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            
            
        } else{
            //本次点击的按钮设为红色
            [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
            
        }
        NSLog(@"点击了第%ld 个按钮", (long)btn.tag - 100);
    
    
    
    
    
}

@end
