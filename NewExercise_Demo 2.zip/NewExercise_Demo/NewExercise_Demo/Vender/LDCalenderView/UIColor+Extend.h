//
//  UIColor+Extend.h
//  LDCalendarView
//
//  Created by lidi on 15/9/22.
//  Copyright © 2015年 lidi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Extend)
+ (UIColor *)hexColorWithString:(NSString *)string;
@end
