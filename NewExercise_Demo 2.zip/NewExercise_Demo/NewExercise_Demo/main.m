//
//  main.m
//  NewExercise_Demo
//
//  Created by 智颜科技 on 2017/11/14.
//  Copyright © 2017年 zy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
